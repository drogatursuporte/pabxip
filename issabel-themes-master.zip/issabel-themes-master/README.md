# issabel-themes
Extra themes for Issabel

These go into `/var/www/html/themes/`
